﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using System.Threading;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {   
        public Form2()
        {
            InitializeComponent();

        }

        public async void Form2_Load(object sender, EventArgs e)
        {

        }
        public async void W(object sender, EventArgs e)
        {
            WebRequest request = WebRequest.Create("http://api.openweathermap.org/data/2.5/weather?q=Wrocław&APPID=b77b7ec969ccb002839ac4fb17eaac42");
            
            request.Method = "POST";


            request.ContentType = "application/x-www-urlencoded";

            WebResponse response = await request.GetResponseAsync();


            string answer = string.Empty;

            using (Stream s = response.GetResponseStream())
            {
                using (StreamReader reader = new StreamReader(s))
                {
                    answer = await reader.ReadToEndAsync();
                }
            }

            response.Close();

            richTextBox1.Text = answer;

            OpenWeather.OpenWeather oW = JsonConvert.DeserializeObject<OpenWeather.OpenWeather>(answer);

            panel1.BackgroundImage = oW.weather[0].Icon;

            label1.Text = "Pogoda:" + oW.weather[0].main;

            label2.Text = "Opis:" + oW.weather[0].description;

            label9.Text = "Temperatura (°C): " + oW.main.temp.ToString("0.##");

            label4.Text = "Wilgotność (%): " + oW.main.humidity.ToString();

            label5.Text = "Ciśnienie (мм): " + ((int)oW.main.pressure).ToString();

            label6.Text = "Prędkość (м/s): " + oW.wind.speed.ToString();

            label7.Text = "Kierunek °: " + oW.wind.deg.ToString();
        }
        public async void Z(object sender, EventArgs e)
        {
            WebRequest request = WebRequest.Create("http://api.openweathermap.org/data/2.5/weather?q=Zdunska Wola&APPID=b77b7ec969ccb002839ac4fb17eaac42");

            request.Method = "POST";

            request.ContentType = "application/x-www-urlencoded";

            WebResponse response = await request.GetResponseAsync();


            string answer = string.Empty;

            using (Stream s = response.GetResponseStream())
            {
                using (StreamReader reader = new StreamReader(s))
                {
                    answer = await reader.ReadToEndAsync();
                }
            }

            response.Close();

            richTextBox1.Text = answer;

            OpenWeather.OpenWeather oW = JsonConvert.DeserializeObject<OpenWeather.OpenWeather>(answer);

            panel1.BackgroundImage = oW.weather[0].Icon;

            label1.Text = "Pogoda:" + oW.weather[0].main;

            label2.Text = "Opis:" + oW.weather[0].description;

            label9.Text = "Temperatura (°C): " + oW.main.temp.ToString("0.##");

            label4.Text = "Wilgotność (%): " + oW.main.humidity.ToString();

            label5.Text = "Ciśnienie (мм): " + ((int)oW.main.pressure).ToString();

            label6.Text = "Prędkość (м/s): " + oW.wind.speed.ToString();

            label7.Text = "Kierunek °: " + oW.wind.deg.ToString();
        }
        public void Wroclaw(object sender, EventArgs e)
        {
            WebRequest request = WebRequest.Create("http://api.openweathermap.org/data/2.5/weather?q=Wrocław&APPID=b77b7ec969ccb002839ac4fb17eaac42");
            this.W(request, e);
            label8.Text = "Wrocław";
            this.Refresh();

        }

        public void Zdw(object sender, EventArgs e)
        {
            WebRequest request = WebRequest.Create("http://api.openweathermap.org/data/2.5/weather?q=Zdunska Wola&APPID=b77b7ec969ccb002839ac4fb17eaac42");
            this.Z(request,e);
            label8.Text = "Zduńska Wola";
            this.Refresh();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Logowanie : Form
    {
        public Logowanie()
        {
            InitializeComponent();
        }
        Form2 Form2 = new Form2();
        private void zalogujBt_Click(object sender, EventArgs e)
        {
            string uzytkownik = this.nazwaUzytktxt.Text;
            string haslo = this.hasloUzyttxt.Text;
            
            if (SprawdzNazweiHaslo(uzytkownik, haslo))
            {
                
                //!!!!!!!!!!!!! dalej tutaj mozecie tworzyc nowe formularze i dalsza czesc programu ...!!!!!!!!!!!
                
                
                
                Form2.ShowDialog();
                

            }
            else
            {
                MessageBox.Show("Niepoprawna nazwa użytkownika lub hasło", "Błąd logowania");
                return;

            }
          
        }

        public bool SprawdzNazweiHaslo(string uzytkownik, string haslo)
            {
                if (uzytkownik == "kuba" & haslo == "kuba")
                    return true;
                else
                    return false;
            }

        private void button1_KeyDown(object sender, KeyEventArgs e)
        {
            string uzytkownik = this.nazwaUzytktxt.Text;
            string haslo = this.hasloUzyttxt.Text;

            if (SprawdzNazweiHaslo(uzytkownik, haslo))
            {

                //!!!!!!!!!!!!! dalej tutaj mozecie tworzyc nowe formularze i dalsza czesc programu ...!!!!!!!!!!!



                Form2.ShowDialog();


            }
            else
            {
                MessageBox.Show("Niepoprawna nazwa użytkownika lub hasło", "Błąd logowania");
                return;

            }
        }


    }
}

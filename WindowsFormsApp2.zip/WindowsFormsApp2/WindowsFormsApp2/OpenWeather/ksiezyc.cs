﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace WindowsFormsApp2.OpenWeather
{
    class ksiezyc
    {
        public string ks;

        public Bitmap  Ks
        {
         get
         {
        return new Bitmap(Image.FromFile($"ks/{ks}.jpg"));
         }
        
        }
    }
}

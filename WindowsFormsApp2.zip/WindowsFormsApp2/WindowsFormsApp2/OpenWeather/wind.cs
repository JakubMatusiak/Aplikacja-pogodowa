﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2.OpenWeather
{
    class wind
    {
        public double speed;

        public double deg;
       
        public double gust;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2.OpenWeather
{
    class sys
    {
        public double type;

        public int id;

        public double message;

        public string country;

        public double sunrise;

        public double sunset;
    }
}
